<thead>
    <tr>
        <th></th>
        <th>Codigo</th>
        <th>Urgencia</th>
        <th>Tipo</th>
        <th>Origem Despesa</th>
        <th>Contrato</th>
    </tr>
</thead>
<tfoot>
    <tr>
        <th></th>
        <th>Codigo</th>
        <th>Urgencia</th>
        <th>Tipo</th>
        <th>Origem Despesa</th>
        <th>Contrato</th>
    </tr>
</tfoot>