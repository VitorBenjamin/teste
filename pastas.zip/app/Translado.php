<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Translado extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'data_translado', 'estornado', 'turno', 'observacao', 'origem', 'destino', 'ida_volta', 'distancia', 'solicitacoes_id','anexo_pdf'
    ];
    
    /** Consulta a solicitacao
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
     public function solicitacao()
    {
        return $this->belongsTo('App\Solicitacao','solicitacoes_id');
    } 

}
